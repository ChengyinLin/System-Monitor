# -*- coding: utf-8 -*-
"""
Intel独立显卡检测逻辑测试
测试优化后的Intel显卡识别能力
"""

def test_intel_detection():
    """测试Intel显卡品牌检测和独立显卡判断逻辑"""
    
    print("=" * 70)
    print("Intel独立显卡检测逻辑测试")
    print("=" * 70)
    
    # 测试用的显卡名称列表
    test_gpu_names = [
        # Intel集成显卡
        ("Intel HD Graphics 630", "集成显卡"),
        ("Intel UHD Graphics 750", "集成显卡"),
        ("Intel Iris Xe Graphics", "集成显卡（但Xe可能为独立）"),
        ("Intel Graphics", "集成显卡"),
        
        # Intel独立显卡（Arc系列）
        ("Intel Arc A770", "独立显卡（Arc）"),
        ("Intel Arc A750", "独立显卡（Arc）"),
        ("Intel Arc A380", "独立显卡（Arc）"),
        ("Intel Arc A310", "独立显卡（Arc）"),
        ("Intel Arc Graphics", "独立显卡（Arc）"),
        
        # Intel独立显卡（Xe系列）
        ("Intel Iris Xe MAX", "独立显卡（Xe MAX）"),
        ("Intel Xe Graphics", "独立显卡（Xe）"),
        
        # Intel独立显卡（DG系列）
        ("Intel DG1", "独立显卡（DG1）"),
        ("Intel DG2", "独立显卡（DG2）"),
        
        # 其他Intel显卡
        ("Intel Discrete Graphics", "独立显卡（Discrete）"),
        ("Intel Graphics [ARC]", "独立显卡（ARC）"),
        
        # 混合名称
        ("NVIDIA GeForce RTX 3080", "NVIDIA显卡"),
        ("AMD Radeon RX 6800", "AMD显卡"),
        ("AMD RX 6700 XT", "AMD显卡"),
    ]
    
    print("\n[品牌检测测试]:")
    print("-" * 50)
    
    for gpu_name, expected_type in test_gpu_names:
        name_lower = gpu_name.lower()
        
        # 品牌检测逻辑（从server.py复制）
        brand = "Other"
        if 'nvidia' in name_lower or 'geforce' in name_lower:
            brand = "NVIDIA"
        elif 'amd' in name_lower or 'radeon' in name_lower or 'rx' in name_lower:
            brand = "AMD"
        elif ('intel' in name_lower or 'arc' in name_lower or 
              'xe' in name_lower or 'dg1' in name_lower or 
              'dg2' in name_lower or 'discrete' in name_lower):
            brand = "Intel"
        
        # Intel独立显卡判断逻辑
        is_dedicated = False
        if brand == "Intel":
            is_dedicated = ('arc' in name_lower or 'xe' in name_lower or 
                          'dg1' in name_lower or 'dg2' in name_lower or
                          'discrete' in name_lower)
        
        # 显示结果
        status = "[OK]" if (brand == "Intel" and "Intel" in expected_type) or \
                        (brand == "NVIDIA" and "NVIDIA" in expected_type) or \
                        (brand == "AMD" and "AMD" in expected_type) else "[X]"
        
        dedicated_mark = " (独立)" if is_dedicated else " (集成)"
        
        print(f"{status} {gpu_name:30} → 品牌: {brand:10}{dedicated_mark if brand == 'Intel' else '':12} | 预期: {expected_type}")
    
    # 测试预设值逻辑
    print("\n[Intel显卡预设值测试]:")
    print("-" * 50)
    
    intel_gpus = [
        ("Intel HD Graphics 630", 2.0, False),   # 集成显卡，2GB共享显存
        ("Intel Arc A770", 8.0, True),          # 独立显卡，8GB显存
        ("Intel Iris Xe Graphics", 4.0, False), # 集成显卡，4GB共享显存
        ("Intel DG1", 4.0, True),               # 独立显卡，4GB显存
    ]
    
    for gpu_name, vram_gb, is_dedicated in intel_gpus:
        if is_dedicated:
            # 独立显卡预设值
            util = 15
            temp = 55
            mem_used = vram_gb * 1024 * 0.2
            preset_type = "独立显卡预设"
        else:
            # 集成显卡预设值
            util = 8
            temp = 40
            mem_used = vram_gb * 1024 * 0.1
            preset_type = "集成显卡预设"
        
        print(f"> {gpu_name:25} | VRAM: {vram_gb:3}GB | {preset_type}")
        print(f"   利用率: {util}% | 温度: {temp}°C | 显存使用: {mem_used:.0f} MB ({mem_used/1024:.1f} GB)")
        print()
    
    # 实际系统检测测试
    print("\n[实际系统GPU检测测试（调用server.py的_get_gpu函数）]:")
    print("-" * 50)
    
    try:
        # 尝试导入server.py中的函数
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        
        from server import _get_gpu
        
        gpu_info = _get_gpu()
        
        print(f"检测到的显卡:")
        print(f"  名称: {gpu_info.get('name', 'Unknown')}")
        print(f"  品牌: {gpu_info.get('brand', 'Unknown')}")
        print(f"  显存: {gpu_info.get('vram_gb', 0)} GB")
        print(f"  利用率: {gpu_info.get('util', 0)}%")
        print(f"  温度: {gpu_info.get('temp', 0)}°C")
        print(f"  驱动版本: {gpu_info.get('driver', 'Unknown')}")
        
        # 判断是否为Intel独立显卡
        if gpu_info.get('brand') == 'Intel':
            name_lower = gpu_info.get('name', '').lower()
            is_dedicated = ('arc' in name_lower or 'xe' in name_lower or 
                          'dg1' in name_lower or 'dg2' in name_lower or
                          'discrete' in name_lower)
            
            if is_dedicated:
                print("  [独立显卡] 检测为Intel独立显卡（已应用独立显卡预设值）")
            else:
                print("  [集成显卡] 检测为Intel集成显卡（已应用集成显卡预设值）")
        
    except ImportError as e:
        print(f"无法导入server.py: {e}")
    except Exception as e:
        print(f"测试出错: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 70)
    print("测试完成")
    print("=" * 70)

if __name__ == '__main__':
    test_intel_detection()
    
    # 等待用户按键退出
    try:
        input("\n按Enter键退出...")
    except:
        pass