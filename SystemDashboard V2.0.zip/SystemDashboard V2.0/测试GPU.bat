@echo off
chcp 65001 >nul
title GPU检测测试
echo.
echo ========================================
echo      AMD/NVIDIA 显卡识别测试
echo ========================================
echo.
cd /d "%~dp0"
python test_gpu.py
pause