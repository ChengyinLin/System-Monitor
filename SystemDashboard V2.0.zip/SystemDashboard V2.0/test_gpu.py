# -*- coding: utf-8 -*-
"""
测试GPU检测功能
"""

import sys
import os
import json

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 直接测试 _get_gpu 函数
def test_gpu():
    try:
        # 导入函数
        import platform
        import subprocess
        
        print("=" * 60)
        print("GPU 检测测试")
        print("=" * 60)
        
        # 直接执行 wmic 命令查看显卡信息
        print("\n1. 使用 WMIC 查询显卡信息...")
        try:
            wmic_result = subprocess.run(
                ['wmic', 'path', 'win32_VideoController', 'get',
                 'name,AdapterCompatibility,DriverVersion,AdapterRAM',
                 '/format:csv'],
                capture_output=True, text=True, encoding='gbk', errors='ignore',
                timeout=5, shell=True
            )
            
            if wmic_result.returncode == 0:
                print(f"WMIC命令执行成功，输出长度: {len(wmic_result.stdout)}")
                print("\n原始输出:")
                print("-" * 40)
                print(wmic_result.stdout[:500])  # 只显示前500字符
                print("-" * 40)
                
                # 解析并显示
                lines = [line.strip() for line in wmic_result.stdout.strip().split('\n') if line.strip()]
                print(f"\n解析到 {len(lines)} 行数据")
                
                if len(lines) > 1:
                    print("\n检测到的显卡:")
                    print("-" * 40)
                    for i, line in enumerate(lines[1:]):  # 跳过标题行
                        parts = [part.strip() for part in line.split(',')]
                        if len(parts) >= 5:
                            print(f"显卡 {i+1}:")
                            print(f"  名称: {parts[4] if len(parts) > 4 else 'Unknown'}")
                            print(f"  厂商: {parts[1] if len(parts) > 1 else 'Unknown'}")
                            print(f"  驱动: {parts[3] if len(parts) > 3 else 'Unknown'}")
                            if len(parts) > 2 and parts[2].strip().isdigit():
                                vram_bytes = int(parts[2])
                                vram_gb = round(vram_bytes / (1024**3), 2)
                                print(f"  显存: {vram_gb} GB ({vram_bytes} bytes)")
                            else:
                                print(f"  显存: 未知")
                            print()
            else:
                print(f"WMIC命令失败，返回码: {wmic_result.returncode}")
                print(f"错误输出: {wmic_result.stderr[:200]}")
                
        except Exception as e:
            print(f"WMIC命令异常: {type(e).__name__}: {e}")
        
        # 测试nvidia-smi
        print("\n2. 测试 NVIDIA-SMI...")
        try:
            nvidia_result = subprocess.run(
                ['nvidia-smi', '--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total',
                 '--format=csv,noheader,nounits'],
                capture_output=True, text=True, encoding='utf-8', timeout=3
            )
            
            if nvidia_result.returncode == 0 and nvidia_result.stdout.strip():
                print("NVIDIA显卡检测到:")
                print(nvidia_result.stdout.strip())
            else:
                print("未检测到NVIDIA显卡或nvidia-smi不可用")
        except Exception as e:
            print(f"NVIDIA检测异常: {type(e).__name__}: {e}")
        
        # 测试AMD检测
        print("\n3. 测试AMD检测...")
        try:
            # 使用wmic数据判断AMD
            if 'wmic_result' in locals() and wmic_result.returncode == 0:
                for line in lines[1:] if 'lines' in locals() else []:
                    parts = [part.strip() for part in line.split(',')]
                    if len(parts) >= 5:
                        name = parts[4] if len(parts) > 4 else "Unknown"
                        name_lower = name.lower()
                        if 'amd' in name_lower or 'radeon' in name_lower or 'rx' in name_lower:
                            print(f"检测到AMD显卡: {name}")
                            vendor = parts[1] if len(parts) > 1 else "Unknown"
                            print(f"  厂商: {vendor}")
        except Exception as e:
            print(f"AMD检测异常: {type(e).__name__}: {e}")
        
        print("\n4. 系统信息:")
        print(f"  操作系统: {platform.system()} {platform.release()}")
        print(f"  处理器: {platform.processor()}")
        
    except Exception as e:
        print(f"测试过程中出错: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()

# 测试server.py中的_get_gpu函数
def test_server_gpu():
    print("\n" + "=" * 60)
    print("测试 server.py 中的 _get_gpu 函数")
    print("=" * 60)
    
    try:
        # 导入server.py中的函数
        from server import _get_gpu
        
        gpu_info = _get_gpu()
        print("\nGPU检测结果:")
        print(json.dumps(gpu_info, indent=2, ensure_ascii=False))
        
        # 分析结果
        print("\n分析:")
        print(f"  显卡品牌: {gpu_info.get('brand', 'Unknown')}")
        print(f"  显卡名称: {gpu_info.get('name', 'Unknown')}")
        print(f"  显存大小: {gpu_info.get('vram_gb', 0)} GB")
        print(f"  利用率: {gpu_info.get('util', 0)}%")
        print(f"  温度: {gpu_info.get('temp', 0)}°C")
        
        # 判断AMD显卡
        if gpu_info.get('brand') == 'AMD':
            print("\n✅ AMD显卡已正确识别！")
            print("   注意: AMD显卡的温度和利用率为预设值（因无官方命令行工具）")
            print("   如需更准确数据，可安装AMD Software: Adrenalin Edition")
        
    except ImportError as e:
        print(f"无法导入server.py: {e}")
        print("请确保server.py在同一目录下")
    except Exception as e:
        print(f"测试出错: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    test_gpu()
    test_server_gpu()
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("按Enter键退出...")
    input()