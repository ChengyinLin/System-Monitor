@echo off
chcp 65001 >nul
title Intel显卡检测优化测试
echo.
echo ========================================
echo   Intel独立显卡检测逻辑优化测试
echo ========================================
echo.
cd /d "%~dp0"
python test_intel_optimization.py
pause